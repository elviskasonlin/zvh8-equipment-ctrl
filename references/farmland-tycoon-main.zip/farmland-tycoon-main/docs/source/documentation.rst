Main
====
.. automodule:: main
   :members:

Source: Auxiliary Functions
===========================
.. automodule:: src.auxfn
   :members:

Source: Game
============
.. automodule:: src.game
   :members:

Source: GUI
===========
.. automodule:: src.gui
   :members:

Source: Game load/save
======================
.. automodule:: src.saves
   :members:

Source: Market
==============
.. automodule:: src.market
   :members:
