"""
market.py

Helper functions for simulating the market
"""

